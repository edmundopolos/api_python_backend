# api_mschool
the flask server
Use text file to install needed dependencies
